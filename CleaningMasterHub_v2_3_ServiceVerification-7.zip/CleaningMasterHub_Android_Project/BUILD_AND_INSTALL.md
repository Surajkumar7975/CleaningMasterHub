# Cleaning Master Hub Android project

This is an Android Studio project wrapping the Cleaning Master Hub mobile booking prototype.

Features:
- Dark green/white UI
- Noida service area
- Listed services and prices
- Furnished/unfurnished deep cleaning packages
- Custom booking form
- WhatsApp booking to +91 9315465699
- Calling number +91 7975038041

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on an Android phone.

The WhatsApp action requires WhatsApp (or a compatible handler) on the phone.
