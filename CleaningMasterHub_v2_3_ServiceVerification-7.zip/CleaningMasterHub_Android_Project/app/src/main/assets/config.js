// Paste your deployed Google Apps Script /exec URL here.
const ONLINE_API_URL = "";
// For automatic WhatsApp OTP + completion/rating messages, configure the matching
// Script Properties in backend/Code.gs. Do not put private API tokens in this file.
