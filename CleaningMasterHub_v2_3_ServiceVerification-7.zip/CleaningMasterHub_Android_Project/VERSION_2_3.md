# Version 2.3 — Verified Service Workflow

Added service-partner workflow: Booking ID → before photo → start OTP → work started → after photo → completion OTP → completed → customer rating.

Also added Google Drive photo storage support through Apps Script, optional automatic WhatsApp OTP/rating messages, and Android WebView camera/file selection support.
