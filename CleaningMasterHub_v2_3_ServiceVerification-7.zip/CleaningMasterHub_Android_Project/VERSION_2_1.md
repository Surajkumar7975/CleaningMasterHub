# Cleaning Master Hub v2.1
- Modern responsive UI for current Android phones and iPhone web/PWA use.
- Service-specific poster assets included.
- Shared online booking backend included (`backend/Code.gs`).
- Local fallback mode included for testing.
- Live booked-slot locking when the online backend URL is configured.
- WhatsApp booking target: 9315465699.
