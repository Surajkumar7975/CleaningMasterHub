# Cleaning Master Hub — Service Partner Workflow

1. Customer books a slot and receives a Booking ID.
2. Service partner opens **Service Partner / Staff** and enters the Booking ID.
3. Partner takes the BEFORE photo inside the app and uploads it.
4. Partner requests the START OTP. If WhatsApp provider is configured, the OTP is sent automatically. Otherwise the app gives a WhatsApp fallback button.
5. Customer tells the OTP to the partner. Partner enters it. Only then does the job become STARTED.
6. After cleaning, partner takes the AFTER photo and uploads it.
7. Partner requests the COMPLETION OTP. Customer receives it and tells it to the partner.
8. Partner verifies the OTP. Job becomes COMPLETED.
9. Customer is prompted to rate the service with 1–5 stars and optional feedback.

## Automatic OTP / rating messages
For true automatic WhatsApp delivery, use WhatsApp Cloud API and configure Script Properties in the Apps Script project. The app never contains the secret token.

Required Script Properties:
- WA_ACCESS_TOKEN
- WA_PHONE_NUMBER_ID
- WA_TEMPLATE_NAME (approved template with OTP + Booking ID body variables)
- WA_RATING_TEMPLATE_NAME (approved template with Booking ID + rating URL body variables)
- WA_TEMPLATE_LANG (example: en_US)
- PUBLIC_APP_URL (public web/PWA URL)
- PHOTO_FOLDER_ID (optional Google Drive folder ID for before/after photos)

Without these properties, staff can still send the generated OTP through the provided WhatsApp button.
