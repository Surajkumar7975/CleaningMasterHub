# Shared Online Booking Setup (one-time)

The app already contains the shared-slot code. To make bookings sync between different Android/iPhone devices, connect the included Google Apps Script backend.

## Steps
1. Create a blank Google Sheet called `Cleaning Master Hub Bookings`.
2. Open **Extensions -> Apps Script**.
3. Delete the sample code and paste `backend/Code.gs` from this project.
4. Save.
5. Click **Deploy -> New deployment**.
6. Select **Web app**.
7. Execute as **Me**.
8. Who has access: **Anyone**.
9. Deploy and copy the URL ending in `/exec`.
10. Open `app/src/main/assets/config.js` and replace the empty value in `ONLINE_API_URL` with that URL.
11. Build the APK again.

After this, a slot booked from one phone is locked on other phones too. The Sheet also keeps the booking list for the business.

## Important
- The current app uses local storage if `ONLINE_API_URL` is empty, so the APK still works for testing.
- For real shared booking, the `/exec` URL must be filled in and a new APK must be built.
- WhatsApp number is already set to 9315465699.


### Customer ratings
The app now includes a 1–5 star customer rating section. Ratings are stored in a separate `Ratings` sheet when the online backend is connected, and the app displays the genuine average, count, distribution and recent comments. The app does not fabricate or inflate ratings.
