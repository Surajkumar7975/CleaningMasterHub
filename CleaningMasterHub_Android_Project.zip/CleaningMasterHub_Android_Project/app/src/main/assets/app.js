const WA="919315465699";
const services=[
 ["Washroom Cleaning",350,"per washroom"],
 ["Kitchen Cleaning",1650,"per kitchen"],
 ["Sofa Cleaning",170,"per seater"],
 ["Cushion Cleaning",50,"per cushion"],
 ["Mattress Cleaning",399,"per mattress"],
 ["Windows / UPVC Glass Cleaning",199,"per window"],
 ["Balcony Cleaning",249,"per balcony"],
 ["Carpet Cleaning (25–50 sq. ft.)",449,"per carpet"],
 ["Fan Cleaning",49,"per fan"],
 ["Chimney Cleaning",499,"per chimney"]
];
const furnished=[["4BHK",7999],["3BHK",6499],["2BHK",4999],["1BHK",3499]];
const unfurnished=[["4BHK",6499],["3BHK",5499],["2BHK",4499],["1BHK",2999]];

const grid=document.querySelector("#serviceGrid"), sel=document.querySelector("#service");
services.forEach(([name,price,unit])=>{
 grid.insertAdjacentHTML("beforeend",`<div class="service"><h3>${name}</h3><div class="price">₹${price.toLocaleString("en-IN")}</div><div class="muted">${unit}</div><button class="outline" onclick="selectService('${name.replaceAll("'","\\'")}')">Book</button></div>`);
 sel.insertAdjacentHTML("beforeend",`<option value="${name}" data-price="${price}">${name}</option>`);
});
function packageHTML(items,kind){
 return items.map(([n,p])=>`<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #e7eee9"><span>${n}</span><strong>₹${p.toLocaleString("en-IN")}</strong></div>`).join("")+
 `<button class="outline" style="margin-top:12px" onclick="selectPackage('${kind}')">Book ${kind}</button>`;
}
document.querySelector("#furnished").innerHTML=packageHTML(furnished,"Furnished Home Deep Cleaning");
document.querySelector("#unfurnished").innerHTML=packageHTML(unfurnished,"Unfurnished Home Deep Cleaning");

function selectService(name){sel.value=name;document.querySelector("#booking").scrollIntoView({behavior:"smooth"});updateTotal();}
function selectPackage(kind){
 let items=kind.startsWith("Furnished")?furnished:unfurnished;
 const bhk=prompt("Enter BHK (1BHK, 2BHK, 3BHK or 4BHK):","2BHK");
 if(!bhk)return;
 const found=items.find(x=>x[0].toUpperCase()===bhk.toUpperCase());
 if(!found){alert("Please enter 1BHK, 2BHK, 3BHK or 4BHK.");return}
 const name=`${kind} - ${found[0]}`;
 if(![...sel.options].some(o=>o.value===name)){sel.insertAdjacentHTML("beforeend",`<option value="${name}" data-price="${found[1]}">${name} — ₹${found[1]}</option>`)}
 sel.value=name;document.querySelector("#qty").value=1;document.querySelector("#booking").scrollIntoView({behavior:"smooth"});updateTotal();
}
function updateTotal(){
 const opt=sel.options[sel.selectedIndex], price=Number(opt?.dataset.price||0), qty=Math.max(1,Number(document.querySelector("#qty").value||1));
 document.querySelector("#total").textContent=price?`Estimated total: ₹${(price*qty).toLocaleString("en-IN")}`:"Estimated total: Visit required";
}
sel.addEventListener("change",updateTotal);document.querySelector("#qty").addEventListener("input",updateTotal);

document.querySelector("#date").min=new Date().toISOString().split("T")[0];
document.querySelector("#bookingForm").addEventListener("submit",e=>{
 e.preventDefault();
 const opt=sel.options[sel.selectedIndex], price=Number(opt?.dataset.price||0), qty=Math.max(1,Number(document.querySelector("#qty").value||1));
 const total=price?price*qty:"Visit required";
 const msg=`*CLEANING MASTER HUB BOOKING*%0A%0AService: ${encodeURIComponent(sel.value)}%0AName: ${encodeURIComponent(document.querySelector("#name").value)}%0AMobile: ${encodeURIComponent(document.querySelector("#mobile").value)}%0AAddress: ${encodeURIComponent(document.querySelector("#address").value)}%0ADate: ${document.querySelector("#date").value}%0ATime: ${document.querySelector("#time").value}%0AQuantity: ${qty}%0AEstimated Total: ${encodeURIComponent(typeof total==="number"?"₹"+total.toLocaleString("en-IN"):total)}`;
 window.open(`https://wa.me/${WA}?text=${msg}`,"_blank");
});
updateTotal();
